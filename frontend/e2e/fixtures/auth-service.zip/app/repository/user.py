from db.database import Database


class UserRepository:
    """Loads and stores users."""

    def find_user(self, username):
        database = Database()
        return database.query("users", username)

    def save_user(self, user):
        database = Database()
        database.insert("users", user)


class CachedUserRepository(UserRepository):
    """Keeps recently loaded users in memory."""

    def clear(self):
        self.cache = {}
