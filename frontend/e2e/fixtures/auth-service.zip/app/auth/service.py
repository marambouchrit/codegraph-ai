"""Authentication of users: password check and access tokens."""
import hashlib

import jwt

from repository.user import UserRepository

SECRET_KEY = "change-me"


class AuthService:
    """Authentication service: logs users in and creates their access tokens."""

    def login(self, username, password):
        """Authentication entry point: check the user's password, then create a token."""
        repository = UserRepository()
        user = repository.find_user(username)
        if user is None or not verify_password(password, user.password_hash):
            raise PermissionError("invalid credentials")
        return self.create_token(user)

    def create_token(self, user):
        """Create a signed JWT access token for an authenticated user."""
        return jwt.encode({"sub": user.id}, SECRET_KEY, algorithm="HS256")


def verify_password(password, password_hash):
    """Compare a password with its stored hash (authentication helper)."""
    return hashlib.sha256(password.encode()).hexdigest() == password_hash
