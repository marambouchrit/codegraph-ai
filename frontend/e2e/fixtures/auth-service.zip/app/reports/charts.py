def render_bar_chart(values, width=40):
    """Draw a horizontal bar chart of monthly sales figures as text."""
    peak = max(values) or 1
    return "\n".join("#" * int(width * value / peak) for value in values)
