class Database:
    """A tiny in-memory database."""

    def query(self, table, key):
        return None

    def insert(self, table, row):
        pass
